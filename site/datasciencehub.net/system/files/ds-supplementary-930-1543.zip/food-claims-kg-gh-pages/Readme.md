[![Badge](https://img.shields.io/badge/View%20Food%20Health%20Claims%20KG%20Metadata-blue?style=for-the-badge)](https://maastrichtu-ids.github.io/food-claims-kg/)

[![SHACL Validation](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/MaastrichtU-IDS/food-claims-kg/gh-pages/status-badge.json&label=SHACL%20Validation)](https://github.com/MaastrichtU-IDS/food-claims-kg/actions/workflows/validate-shacl.yml)


[![100.00 % FAIR](https://img.shields.io/badge/FAIR_assessment-100.00_%25-green)](https://fair-checker.france-bioinformatique.fr/?t=1&resource=https://maastrichtu-ids.github.io/food-claims-kg/)
