Genuine Semantic Publishing: Paper and Data
===========================================

This dataset contains the data for the paper "Genuine Semantic Publishing",
consisting of different representations of the paper's content, including PDF
and HTML versions for human readers and RDF representations for software agents.

The online version of the paper and its data can be found here:
http://www.tkuhn.org/pub/sempub/
