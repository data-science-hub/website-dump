Genunine Semantic Publishing - Revised version of position paper
================================================================

See `index.html` for different representations of the paper (including PDF and
HTML).

See `response.md` for our point-by-point responses.

See `sempub-diff.pdf` for highlighted changes from the first submission.
