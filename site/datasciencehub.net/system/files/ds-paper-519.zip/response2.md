We would like to thank again all reviewers for their very helpful comments. We
respond to the specific points below. In addition, we made many small changes
and shortened the manuscript a bit for this final version.


> Review #1 (Sarven Capadisli)

> [on https://gitter.im/linkedresearch/] I'm not sure if a change is needed for
> your article, but I sense that when it talks about dokieli, there is emphasis
> on publishing articles in/around Scholarly HTML, like strictly for marking and
> publishing articles. [...]

We make it now clear that by "scholarly HTML" we are referring to all kinds of
approaches that advocate HTML for scholarly communication, and not just the work
by the W3C group with that name. We also clarify that these scholarly
HTML-related approaches, including Dokieli, can enable genuine semantic
publishing but are not a direct guarantee for achieving it.


> Review #3 (Jodi Schneider)

> Scholarly communication is not mentioned in the title. Please add it there.

We carefully considered this suggestion, but eventually decided to stick with
the current title for three reasons. First, it is short and crisp, and therefore
more memorable than what a longer title would be. Second, we think we make our
focus sufficiently clear in the first sentence of the abstract and in the
introduction. And third, while we clearly focus on scholarly communication, our
ideas and concepts can be applied to publishing in general, and therefore our
current title is even in its most general interpretation not misleading.

> No data repository appears to be used for the semantic contribution.

We only wanted to publish it once we knew it would be the final version. It is
now available on figshare: https://doi.org/10.6084/m9.figshare.5422726

> The notion of how small a contribution could be is only minimally address;
> this is an important aspect of the proposal that the authors do not thoroughly
> emphasize.

We think we do, as we dedicate about half a page on an example to illustrate
this aspect (starting from "To illustrate the last criterion of ...").

> The field of science mapping could be mentioned more explicitly, e.g. Chen,
> Chaomei, Dubin, Rachael and Schultz, Timothy. 2015. Science mapping. In
> Encyclopedia of Information Science and Technology, Third Edition. IGI Global,
> 4171-4184. (if this is what you mean by the term).

This is an interesting aspect and we considered adding it, but we came to the
conclusion that it would lead us too far away from the core message of our
article (and we are already stretching the length limit).

> Reviews are public, so consider mentioning reviewers by name.

The names of all non-anonymous reviewers will be shown prominently at the top of
the article, just below the author details. Therefore we think it is not
necessary to repeat their names in the acknowledgement section.

> Apologies for holding this up, it's been a really busy month!

No need to apologize. We thank you for your very valuable and thorough review.

> Data interoperability could be more explicitly mentioned (e.g. around the "We
> propose the definition..."); it seems to me that in a "normal" science, that
> data interoperability is really the point.

Agreed. We write now "... in a *shared and interoperable* semantic notation, ...".
